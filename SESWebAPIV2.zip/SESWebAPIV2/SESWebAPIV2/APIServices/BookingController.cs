﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SESWebAPIV2.Models;
using SESWebAPIV2.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SESWebAPIV2.APIServices
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class BookingController : ControllerBase
    {
        private readonly IBookingRepository<int, Booking> _repository;

        public BookingController(IBookingRepository<int, Booking> Repository)
        {
            _repository = Repository;
        }
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult<List<Booking>>> GetAll()
        {
            var Bookings = await _repository.GetAll();
            return Bookings.ToList();
        }
        [HttpPost]
        public async Task<ActionResult<Booking>> Post(Booking Booking)
        {
            return await _repository.Add(Booking);
        }
        [HttpGet]
        [Route("GetBookingByID/{id}")]
        public async Task<ActionResult<Booking>> Get(int id)
        {
            return await _repository.Get(id);
        }
    }
}