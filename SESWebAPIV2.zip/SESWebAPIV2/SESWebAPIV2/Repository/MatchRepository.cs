﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SESWebAPIV2.Models;

namespace SESWebAPIV2.Repository
{
    public class MatchRepository : IMatchRepository<int, Match>
    {
        private readonly MatchContext _context;
        private readonly ILogger<MatchRepository> _logger;

        public MatchRepository(MatchContext context, ILogger<MatchRepository> logger)
        {
            _context = context;
            _logger = logger;
        }
        public async Task<Match> Add(Match item)
        {
            try
            {
                _context.Matches.Add(item);
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception exception)
            {
                _logger.LogError(exception.Message);
                _logger.LogError("----" + DateTime.Now.ToString());
            }
            return null;
        }

        public async Task<Match> Delete(int key)
        {
            try
            {
                var item = await Get(key);
                _context.Matches.Remove(item);
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Deleting Match");
            }
            return null;
        }

        public async Task<Match> Get(int key)
        {
            try
            {
                var item = _context.Matches.FirstOrDefault(p => p.MatchId == key);

                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Retrieving Match Details");
            }
            return null;
        }

        public async Task<ICollection<Match>> GetAll()
        {
            return _context.Matches.ToList();
        }

        public async Task<Match> Update(Match item)
        {
            try
            {
                //var match = await Get(item.Id);
                //match.Capacity = item.Capacity;
                //match.Name = item.Name;
                //await _context.SaveChangesAsync();
                //return item;
                var match = await Get(item.MatchId);
                match.TeamA = item.TeamA;
                match.TeamAURL = item.TeamAURL;
                match.TeamB = item.TeamB;
                match.TeamBURL = item.TeamBURL;
                match.Date = item.Date;
                match.Time = item.Time;
                match.Location = item.Location;
                await _context.SaveChangesAsync();
                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in updating Match");
            }
            return null;
        }
    }

}
