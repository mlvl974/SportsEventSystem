﻿using System;
using SESWebAPIV2.Models;

namespace SESWebAPIV2.Repository
{
    public interface IToken
    {
        string GenerateToken(AdminLoginDTO admin);
    }
}
