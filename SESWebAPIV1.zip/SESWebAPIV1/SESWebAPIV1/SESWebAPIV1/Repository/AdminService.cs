﻿using Microsoft.Extensions.Logging;
using SESWebAPIV1.Models;
using System.Linq;

namespace SESWebAPIV1.Repository
{
    public class AdminService : IAdmin
    {
        private readonly MatchContext _context;
        private readonly ILogger<AdminService> _logger;

        public AdminService(MatchContext context, ILogger<AdminService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public AdminLoginDTO Login(AdminLoginDTO admin)
        {
            var dbAdmin = _context.Admins.FirstOrDefault(adm => admin.Username == admin.Username);
            if (dbAdmin == null)
                return null;
            admin.Password = "";
            return admin;
        }
    }
}
