﻿using Microsoft.Extensions.Logging;
using SESWebAPIV1.Models;
using System;
using System.Linq;

namespace SESWebAPIV1.Repository
{
    public class AdminService : IAdmin
    {
        private readonly MatchContext _context;
        private readonly ILogger<AdminService> _logger;

        public AdminService(MatchContext context, ILogger<AdminService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public AdminLoginDTO Login(AdminLoginDTO admin)
        {
            var dbAdmin = _context.Admins.FirstOrDefault(adm => admin.Username == admin.Username);
            if (dbAdmin == null)
                return null;
            for (int i = 0; i < admin.Password.Length; i++)
            {
                if (admin.Password[i] != dbAdmin.Password[i])
                    return null;
            }
            admin.Password = "";
            return admin;
        }

        //public AdminLoginDTO Register(AdminDTO admin)
        //{
        //    Admin dbUSer = new Admin();
        //    dbUSer.Username = admin.Username;
        //    dbUSer.Password = admin.Password;
        //    _context.Admins.Add(dbUSer);
        //    try
        //    {
        //        _context.SaveChanges();
        //        AdminLoginDTO myUSer = new AdminLoginDTO()
        //        {
        //            Username = admin.Username
        //            //Role = user.Role
        //        };
        //        //myUSer.Token = _tokenService.GenerateToken(myUSer);
        //        return myUSer;
        //    }
        //    catch (Exception e)
        //    {
        //        _logger.LogError(e.Message + " " + DateTime.Now);
        //    }
        //    return null;
        //}
    }
}
