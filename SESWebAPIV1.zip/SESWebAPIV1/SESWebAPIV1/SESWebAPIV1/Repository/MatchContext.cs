using System;
using SESWebAPIV1.Models;

using Microsoft.EntityFrameworkCore;

namespace SESWebAPIV1.Repository
{
    public class MatchContext : DbContext
    {
        public MatchContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Match> Matches { get; set; }
        public DbSet<Player> Players { get; set; }
        public DbSet<Team> Teams { get; set; }
        public DbSet<Field> Fields { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Admin> Admins { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>().HasData(new Admin()
            {
                Username="admin",
                Password="admin123",
            });

            modelBuilder.Entity<Player>().HasData(new Player()
            {
                Id = 1,
                TeamId = 100,
                FullName = "Hariss Harun",
                JerseyNumber = 14,
                FieldPosition = "Midfielder",
            });
            modelBuilder.Entity<Player>().HasData(new Player()
            {
                Id = 2,
                TeamId = 101,
                FullName = "Thiago Silva",
                JerseyNumber = 3,
                FieldPosition = "Defender",
            });

            modelBuilder.Entity<Team>().HasData(new Team()
            {
                TeamId = 100,
                TeamName = "Singapore",
                TeamCaptain = 100,
                TeamManager = "Nazri Nasir",
                TeamURL = "https://cdn.countryflags.com/thumbs/singapore/flag-round-250.png"
            });
            modelBuilder.Entity<Team>().HasData(new Team()
            {
                TeamId = 101,
                TeamName = "Brazil",
                TeamCaptain = 101,
                TeamManager = "Adenor Leonardo Bacchi",
                TeamURL = "https://cdn.countryflags.com/thumbs/brazil/flag-round-250.png"
            });
            modelBuilder.Entity<Match>().HasData(new Match()
            {

                MatchId = 1,
                TeamA = "Brazil",
                TeamAURL = "https://cdn.countryflags.com/thumbs/brazil/flag-round-250.png",
                TeamB = "Singapore",
                TeamBURL = "https://cdn.countryflags.com/thumbs/singapore/flag-round-250.png",
                Date = "11-05-2022",
                Time = "12:30 PM",
                Location = "S?o Paulo",
            });

            modelBuilder.Entity<Field>().HasData(new Field()
            {
                FieldId = 1,
                FieldName = "Est?dio do Morumb",
                FieldCity = "S?o Paulo",
                MatchId = 1,
                FieldCapacity = 67052,
                FieldURL = "https://www.stadiumguide.com/wp-content/uploads/alwakrah_top.jpg"
            });
            modelBuilder.Entity<Field>().HasData(new Field()
            {
                FieldId = 2,
                FieldName = "Lusail Stadium",
                FieldCity = "Lusail",
                MatchId = 1,
                FieldCapacity = 80000,
                FieldURL = "https://www.stadiumguide.com/wp-content/uploads/lusail2022-1.jpg"
            });
            modelBuilder.Entity<Field>().HasData(new Field()
            {
                FieldId = 3,
                FieldName = "Al Bayt Stadium",
                FieldCity = "Al Khor",
                MatchId = 1,
                FieldCapacity = 60000,
                FieldURL = "https://www.stadiumguide.com/wp-content/uploads/albayt_top.jpg"
            });

            modelBuilder.Entity<Booking>().HasData(new Booking()
            {
                BookingId = 1,
                MatchId = 1,
                Price = 100.00f,
                Quantity = 2,
                TotalPrice = 200.00f
            });            
        }
    }
}