using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SESWebAPIV1.Models;

namespace SESWebAPIV1.Repository
{
    public class FieldRepository : IFieldRepository<int, Field>
    {
        private readonly MatchContext _context;
        private readonly ILogger<FieldRepository> _logger;

        public FieldRepository(MatchContext context, ILogger<FieldRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<Field> Get(int key)
        {
            try
            {
                var item = _context.Fields.FirstOrDefault(p => p.FieldId == key);

                return item;
            }
            catch (Exception e)
            {
                _logger.LogError("Error in Retrieving Field Details");
            }
            return null;
        }

        public async Task<ICollection<Field>> GetAll()
        {
            return _context.Fields.ToList();
        }
    }
}
