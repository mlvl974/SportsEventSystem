using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SESWebAPIV1.Models;
using SESWebAPIV1.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SESWebAPIV1.APIServices
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class BookingController : ControllerBase
    {
        private readonly IBookingRepository<int, Booking> _repository;

        public BookingController(IBookingRepository<int, Booking> Repository)
        {
            _repository = Repository;
        }
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult<List<Booking>>> GetAll()
        {
            var Bookings = await _repository.GetAll();
            return Bookings.ToList();
        }
        [HttpPost]
        public async Task<ActionResult<Booking>> Post(Booking Booking)
        {
            return await _repository.Add(Booking);
        }
        [HttpGet]
        [Route("GetBookingByID/{id}")]
        public async Task<ActionResult<Booking>> Get(int id)
        {
            return await _repository.Get(id);
        }
        [HttpPut]
        public async Task<ActionResult<Booking>> Update(Booking booking)
        {
            return await _repository.Update(booking);

        }
        [HttpDelete]
        public async Task<ActionResult<Booking>> Delete(int id)
        {
            return await _repository.Delete(id);
        }
    }
}