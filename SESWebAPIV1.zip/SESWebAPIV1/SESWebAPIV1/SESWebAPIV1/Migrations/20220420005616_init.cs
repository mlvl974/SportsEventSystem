﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SESWebAPIV1.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Admins",
                columns: table => new
                {
                    Username = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Admins", x => x.Username);
                });

            migrationBuilder.CreateTable(
                name: "Bookings",
                columns: table => new
                {
                    BookingId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Price = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    MatchId = table.Column<int>(type: "int", nullable: false),
                    TotalPrice = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bookings", x => x.BookingId);
                });

            migrationBuilder.CreateTable(
                name: "Fields",
                columns: table => new
                {
                    FieldId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FieldName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FieldCity = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MatchId = table.Column<int>(type: "int", nullable: false),
                    FieldCapacity = table.Column<int>(type: "int", nullable: false),
                    FieldURL = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Fields", x => x.FieldId);
                });

            migrationBuilder.CreateTable(
                name: "Matches",
                columns: table => new
                {
                    MatchId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TeamA = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TeamAURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TeamB = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TeamBURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Date = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Time = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Location = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Matches", x => x.MatchId);
                });

            migrationBuilder.CreateTable(
                name: "Players",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FullName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    JerseyNumber = table.Column<int>(type: "int", nullable: false),
                    FieldPosition = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TeamId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Players", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Teams",
                columns: table => new
                {
                    TeamId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TeamName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TeamCaptain = table.Column<int>(type: "int", nullable: false),
                    TeamManager = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TeamURL = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Teams", x => x.TeamId);
                });

            migrationBuilder.InsertData(
                table: "Admins",
                columns: new[] { "Username", "Password" },
                values: new object[] { "admin", "admin123" });

            migrationBuilder.InsertData(
                table: "Bookings",
                columns: new[] { "BookingId", "MatchId", "Price", "Quantity", "TotalPrice" },
                values: new object[] { 1, 1, 100, 2, 200 });

            migrationBuilder.InsertData(
                table: "Fields",
                columns: new[] { "FieldId", "FieldCapacity", "FieldCity", "FieldName", "FieldURL", "MatchId" },
                values: new object[,]
                {
                    { 1, 67052, "Sao Paulo", "Estadio do Morumb", "https://www.stadiumguide.com/wp-content/uploads/alwakrah_top.jpg", 1 },
                    { 2, 80000, "Lusail", "Lusail Stadium", "https://www.stadiumguide.com/wp-content/uploads/lusail2022-1.jpg", 1 },
                    { 3, 60000, "Al Khor", "Al Bayt Stadium", "https://www.stadiumguide.com/wp-content/uploads/albayt_top.jpg", 1 }
                });

            migrationBuilder.InsertData(
                table: "Matches",
                columns: new[] { "MatchId", "Date", "Location", "TeamA", "TeamAURL", "TeamB", "TeamBURL", "Time" },
                values: new object[] { 1, "11-05-2022", "Sao Paulo", "Brazil", "https://cdn.countryflags.com/thumbs/brazil/flag-round-250.png", "Singapore", "https://cdn.countryflags.com/thumbs/singapore/flag-round-250.png", "12:30 PM" });

            migrationBuilder.InsertData(
                table: "Players",
                columns: new[] { "Id", "FieldPosition", "FullName", "JerseyNumber", "TeamId" },
                values: new object[,]
                {
                    { 1, "Midfielder", "Hariss Harun", 14, 100 },
                    { 2, "Defender", "Thiago Silva", 3, 101 }
                });

            migrationBuilder.InsertData(
                table: "Teams",
                columns: new[] { "TeamId", "TeamCaptain", "TeamManager", "TeamName", "TeamURL" },
                values: new object[,]
                {
                    { 100, 100, "Nazri Nasir", "Singapore", "https://cdn.countryflags.com/thumbs/singapore/flag-round-250.png" },
                    { 101, 101, "Adenor Leonardo Bacchi", "Brazil", "https://cdn.countryflags.com/thumbs/brazil/flag-round-250.png" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Admins");

            migrationBuilder.DropTable(
                name: "Bookings");

            migrationBuilder.DropTable(
                name: "Fields");

            migrationBuilder.DropTable(
                name: "Matches");

            migrationBuilder.DropTable(
                name: "Players");

            migrationBuilder.DropTable(
                name: "Teams");
        }
    }
}
