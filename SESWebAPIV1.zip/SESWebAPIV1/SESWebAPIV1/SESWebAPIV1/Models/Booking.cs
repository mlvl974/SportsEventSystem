using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SESWebAPIV1.Models
{
    public class Booking
    {
        [Key]
        public int BookingId { get; set; }

        public int Price { get; set; }

        public int Quantity { get; set; }

        public int MatchId { get; set; }

        public int TotalPrice { get; set; }
    }
}
