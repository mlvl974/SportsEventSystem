
using System.ComponentModel.DataAnnotations;

namespace SESWebAPIV1.Models
{
    public class Player
    {
        [Key]
        public int Id { get; set; }

        public string FullName { get; set; }

        public int JerseyNumber { get; set; }

        public string FieldPosition { get; set; }

        public int TeamId { get; set; }
        
    }
}



