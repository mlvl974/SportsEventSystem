
namespace SESWebAPIV1.Models
{
    public class AdminDTO
    {
        public string Username { get; set; }

        public string Password { get; set; }

    }
}



