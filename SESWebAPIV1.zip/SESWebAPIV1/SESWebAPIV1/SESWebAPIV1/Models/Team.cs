using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SESWebAPIV1.Models
{
    public class Team
    {
        [Key]
        public int TeamId { get; set; }

        public string TeamName { get; set; }
        public int TeamManager { get; set; }
        public string TeamCoach { get; set; }
        public string TeamURL { get; set; }


        //public string Country { get; set; }
    }
}
