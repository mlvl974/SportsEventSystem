using System;
namespace SESWebAPIV1.Models
{
    public class AdminDTO
    {
        // For Admin to Register
        // This data will be input for admin to login
        // the password is in string format
        // Upon signing up, admin will receive a token and password is encrypted

        public string Username { get; set; }
        public string Password { get; set; }
        public string FullName { get; set; }
        public int Age { get; set; }
        public string Phone { get; set; }
    }
}
