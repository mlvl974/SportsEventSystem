using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SESWebAPIV1.Models
{
    public class Field
    {
        [Key]
        public int FieldId { get; set; }

        public string FieldName { get; set; }

        public string FieldCity { get; set; }

        public int MatchId { get; set; }

     }
}
